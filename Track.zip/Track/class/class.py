# fruitslist = ['apple', 'banana', 'cherry','A']
# for item in fruitslist:
#     print(item)


# ----- for loop in range ----------
 
# for item in range (10):
#     print(item)


# ---------------------------------------------------
# While Loop 
# ---------------------------------------------------

# for i in range(3):
#  print(i)




# i = 6
# while i > 5:
#  print(i)
#  i-=1

# x = 11
# y = 3
# print(x % y)

# ----------------------

# def a():
#  print('Hello World')

# print a()

# -------------

# a = 50
# b = 20
# if not a > b:
#  print(a," is NOT greater than", b)
# else:
#  print('none')