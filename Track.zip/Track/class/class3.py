# def my_func (a,b,c):
#     result = a * 3 + b * 2 + c
#     return result

# r = my_func(a=10, b=20, c=30)
# print(r)


# ---------------------------
# Recursion
# -----------------------------
# def print_x(x):
#     print(x)
#     print_x(x)

# print_x(10)


# ------------------------------------
# function under the function
# ------------------------------------
# def fnc(n1,n2):
#     print("Received", n1,n2)
    
#     def is_even(n):
#         if n % 2 == 0:
#             return True
#         return False
    
#     print("n1 is even :",is_even(n1))
#     print("n2 is odd :", is_even(n2))

# fnc(10,11)



# --------------------------------

# ------------------------------------

















